from django.core.exceptions import ValidationError
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_protect
from django.views.generic import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.utils.safestring import mark_safe
import json
from .models import ChatRoom, Message, VideoCall
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.contrib.auth.decorators import login_required


class LobbyView(LoginRequiredMixin, View):
    login_url = 'account:login'

    def get(self, request):
        user = request.user
        chat_rooms = ChatRoom.objects.all().prefetch_related('members')  # Retrieve all rooms
        return render(request, 'chat_app/lobby.html', {'chat_rooms': chat_rooms})

    def post(self, request):
        # post method for checking room existence and user - used for search room feature
        room_name = request.POST.get('room_name', None)
        user = request.user
        if room_name and user:
            try:
                chat_room = ChatRoom.objects.get(room_name=room_name)
                if user in chat_room.members.all():
                    return JsonResponse({'status': 409})
                else:
                    return JsonResponse({"status": 200})
            except ChatRoom.DoesNotExist:
                return JsonResponse({"status": 404})
        return JsonResponse({'status': 400})


class RoomView(LoginRequiredMixin, View):
    login_url = 'account:login'

    def get(self, request, room_slug):
        username = request.user.username
        try:
            chat_model = ChatRoom.objects.get(slug=room_slug)
            message_model = Message.objects.filter(chat_room=chat_model).select_related('chat_room', 'author')
            context = {
                'message_model': message_model,
                'chat_model': chat_model,
                'room_name': chat_model.room_name,
                'username': mark_safe(json.dumps(username)),
            }
            return render(request, 'chat_app/room.html', context=context)
        except ChatRoom.DoesNotExist:
            raise ValidationError('Room does not exist, Maybe it was deleted by its creator')


@login_required(login_url='account:login')
@csrf_protect
def create_room_view(request):
    if request.method == 'POST':
        user = request.user
        room_name = request.POST.get('room_name', None)
        if not room_name:
            return JsonResponse({'status': 400})
        elif ChatRoom.objects.filter(room_name=room_name).exists():
            return JsonResponse({'status': 409})
        else:
            created_room = ChatRoom.objects.create(room_name=room_name, creator=user)
            created_room.members.add(user)
            return JsonResponse({'status': 200})


from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_http_methods
from django.views.decorators.http import require_POST

class JoinRoomView(View):
    @require_POST    

    @method_decorator(login_required(login_url='account:login'))
    @require_http_methods(['POST'])
    def post(self, request, room_slug=None):
        user = request.user

        # Send immediate "request sent" response
        response_data = {'status': 202, 'message': 'Request sent'}

        try:
            # Check for room existence (adjust if needed)
            if room_slug:
                room = get_object_or_404(ChatRoom, slug=room_slug)
            else:
                # Handle cases where no slug is provided if applicable
                raise Exception("Room slug not found")

            # Check user membership (optional)
            if user in room.members.all():
                return JsonResponse({'status': 400, 'error': 'User already a member'})

            # Process joining logic
            response = self.join_room_logic(user, room)
            return response

        except ChatRoom.DoesNotExist:
            # Handle room not found if needed
            return JsonResponse({'status': 404, 'error': 'Room not found'})
        except Exception as e:
            print(f"Unexpected error: {e}")  # Log for troubleshooting

            return JsonResponse({'status': 400})  # Generic error response

    def join_room_logic(self, user, room):
        if user in room.members.all():
            return JsonResponse({'status': 400, 'error': 'User already a member'})

        try:
            room.members.add(user)
            room.save()
            return JsonResponse({
                'status': 'success',
                'message': f'{user.username} joined the room'
            })
        except Exception as e:
            print(f"Unexpected error: {e}")
            return JsonResponse({'status': 400, 'error': 'Failed to join room'})




@login_required(login_url='account:login')
def remove_room(request):
    room_name = request.GET.get('room_name', None)
    user = request.user
    room_group_name = f'chat_{room_name}'
    chat_room = ChatRoom.objects.get(room_name=room_name)
    if room_name and user:
        if user == chat_room.creator:
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                room_group_name, {
                    'type': 'chat_message',
                    'command': 'info',
                    'content': {'type': 'delete', 'message': 'Creator delete the room'},
                }
            )
            chat_room.delete()
        else:
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                room_group_name, {
                    'type': 'chat_message',
                    'command': 'info',
                    'content': {
                        'type': 'left',
                        'message': f'{user.username} left the room',
                        'username': user.username,
                    },
                }
            )
            chat_room.members.remove(user)
        return JsonResponse({'status': 200})
    return JsonResponse({'status': 400})


@login_required(login_url='account:login')
def video_call(request, room_slug):
    user = request.user
    chat_room_name = ChatRoom.objects.get(slug=room_slug).room_name
    call_logs = VideoCall.objects.filter(Q(callee_id=user.id) | Q(caller_id=user.id)).order_by('-date_created')[:5]
    return render(request, 'chat_app/video_call.html', {
        'call_logs': call_logs,
        'room_name': mark_safe(json.dumps(chat_room_name)),
    })


from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.core.files.storage import default_storage
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Message

@login_required
def send_message(request, room_name):
    """
    View for handling sending messages (text, image, or voice note) to a chat room.
    """
    username = request.user.username

    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed (POST required)'}, status=405)

    content = request.POST.get('message')
    content_type = 'message'

    if request.FILES.get('image'):
        image = request.FILES['image']
        content_type = 'image'
    elif request.FILES.get('voice_note'):
        voice_note = request.FILES['voice_note']
        content_type = 'voice_note'

    # Basic validation for uploaded files
    # ... (same as before)

    # Retrieve the ChatRoom object based on room_name (assuming 'room_name' field)
    try:
        chat_room = ChatRoom.objects.get(room_name=room_name)
    except ChatRoom.DoesNotExist:
        return JsonResponse({'error': 'Chat room not found'}, status=404)

    # Create and save the message object
    try:
        message = Message.objects.create(
            chat_room=chat_room,  # Use the retrieved ChatRoom object
            author=request.user,
            content=content if content_type == 'message' else None,
            image=request.FILES.get('image'),
            voice_note=request.FILES.get('voice_note'),
        )
    except Exception as e:
        print(f"Error saving message: {e}")
        messages.error(request, f"Error saving message: {e}")
        return JsonResponse({'error': 'An error occurred while saving the message'}, status=500)

    # Process and save the message content (placeholder for additional logic)
    # ...

    # Prepare data for success response
    data = {
        'content': message.content if content_type == 'message' else "",  # Include empty string for no text content
        'username': username,
        'created_at': message.created_at.strftime('%H:%M:%S'),  # Formatted time
    }
    return JsonResponse(data)

from django.utils import timezone

def get_new_messages(request, room_name):
    """
    View to retrieve new messages for a specific chat room using long polling.
    """

    # Retrieve the ChatRoom object based on room_name (assuming 'room_name' field)
    try:
        chat_room = ChatRoom.objects.get(room_name=room_name)
    except ChatRoom.DoesNotExist:
        return JsonResponse({'error': 'Chat room not found'}, status=404)

    # Last message seen timestamp (sent by the client)
    last_seen_timestamp = request.GET.get('last_seen', None)

    if not last_seen_timestamp:
        # No last_seen provided, return the most recent message
        messages = Message.objects.filter(chat_room=chat_room).order_by('-created_at').first()
    else:
        # Filter messages since the last_seen timestamp
        try:
            last_seen_datetime = timezone.parse(last_seen_timestamp)
        except (ValueError, OverflowError):
            # Handle invalid timestamp format
            return JsonResponse({'error': 'Invalid last_seen timestamp'}, status=400)

        messages = Message.objects.filter(
            chat_room=chat_room, created_at__gt=last_seen_datetime
        ).order_by('-created_at')

    # Prepare data for response (limited to new messages)
    data = []
    for message in messages:
        data.append({
            'content': message.content if message.content_type == 'message' else "",
            'username': message.author.username,
            'created_at': message.created_at.strftime('%H:%M:%S'),
        })

    return JsonResponse(data, safe=False) # Allow for non-dictionary serializable data (models)
