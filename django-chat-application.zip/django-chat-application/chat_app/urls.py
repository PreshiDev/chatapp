from django.urls import path
from . import views


app_name = 'chat'
urlpatterns = [
    path('lobby', views.LobbyView.as_view(), name='lobby'),
    path('room/<slug:room_slug>', views.RoomView.as_view(), name='room'),
    path('create', views.create_room_view, name='create-room'),
    path('join_room/', views.JoinRoomView.as_view(), name='join_room_without_slug'),
    path('join_room/<slug:room_slug>/', views.JoinRoomView.as_view(), name='join_room_with_slug'),
    path('chat/<str:room_name>/send_message/', views.send_message, name='send_message'),
    path('remove-room', views.remove_room, name='remove-room'),
    path('chat/<room_name>/get_new_messages/', views.get_new_messages, name='get_new_messages'),
]
