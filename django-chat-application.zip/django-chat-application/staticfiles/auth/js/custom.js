$(document).ready(function() {
    $("#userInfoButton, #otherButtonId").click(function(e) {  // Target both buttons by ID
      e.preventDefault();  // Prevent default form submission
  
      var url = $(this).data("url");  // Get the URL from the clicked button's data-url attribute
  
      $.ajax({
        url: url,
        method: "GET",
        success: function(response) {
          $("#userInfoContent").html(response);  // Update the modal content with the fetched response
          $('.modal').modal('handleUpdate');  // Bootstrap v5+ syntax
        },
        error: function(error) {
          console.error("Error fetching content:", error);  // Log any errors
          // Display user-friendly error message in the modal (optional)
        }
      });
    });
});


  