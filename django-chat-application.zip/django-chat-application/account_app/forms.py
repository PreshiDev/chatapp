from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import User
from django import forms
from django.core import validators


class CustomUserCreationForm(UserCreationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['first_name'].required = True  # Make first_name required
        self.fields['last_name'].required = True  # Make last_name required
        self.fields['profile_picture'] = forms.ImageField(required=False)  # Optional profile picture

    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'profile_picture', 'password1', 'password2')

    def clean_email(self):
        """
        Custom validation to check if the email already exists for another user.
        """
        email = self.cleaned_data['email']
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('This email address is already in use.')
        return email


class CustomUserChangeForm(UserChangeForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['first_name'].required = True
        self.fields['last_name'].required = True

    class Meta:
        model = User
        fields = '__all__'


class EditProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'profile_picture')

    def clean_email(self):
        """
        Custom validation to check if the email already exists for another user (except the current user).
        """
        email = self.cleaned_data['email']
        user = self.instance  # Access the current user instance
        if User.objects.filter(email=email).exclude(pk=user.pk).exists():
            raise forms.ValidationError('This email address is already in use.')
        return email
