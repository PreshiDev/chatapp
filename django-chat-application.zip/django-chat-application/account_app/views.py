from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views.generic import View
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.csrf import csrf_protect
from django.utils.decorators import method_decorator
from .models import User, Otp
from django.db.models import Q
from .email_module import send_email
from random import randint
from uuid import uuid4
from django.contrib.auth.hashers import make_password
from django.core.files.base import ContentFile
from django.contrib.auth.decorators import login_required
from .forms import EditProfileForm
from .forms import CustomUserCreationForm  # Assuming the form is in the same directory as the view



class LoginView(View):
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('chat:lobby')
        else:
            return render(request, 'account_app/auth.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username and password:
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return JsonResponse({'status': 200, 'username': user.username})
            else:
                return JsonResponse({'status': 401})
        return JsonResponse({'status': 400})


"""
class RegisterView(View):
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('chat:lobby')
        return redirect('account:login')

    @login_required
    def post(self, request):
        data = request.POST
        profile_pic = request.FILES.get('profile_picture')

        if all(data.values()) and None not in data.values():
            if data['password'] != data['confirm_pass']:
                return JsonResponse({'status': 400, 'message': 'passwords conflict'})
            elif User.objects.filter(Q(username=data['username']) | Q(email=data['email'])).exists():
                return JsonResponse({'status': 409, 'message': 'Username or email already exists'})
            else:
                # Create new user and authenticate
                user = User.objects.create(
                    username=data['username'],
                    email=data['email'],
                    password=make_password(data['password'])  # Hash password securely
                )

                if profile_pic:
                    # Validate image file type and size
                    if not profile_pic.content_type.startswith('image/'):
                        return JsonResponse({'status': 400, 'message': 'Invalid image format'})
                    if profile_pic.size > 1048576:  # 1 MB limit
                        return JsonResponse({'status': 400, 'message': 'Image exceeds size limit (1 MB)'})

                    # Create a unique filename
                    filename = f'profile_pic_{user.id}.{profile_pic.name.split(".")[-1]}'
                    user.profile_picture = filename

                    # Save the image to the media storage
                    user.save()
                    with open(f'path/to/media/{filename}', 'wb') as f:  # Replace with your media root
                        f.write(profile_pic.read())

                user = authenticate(username=data['username'], password=data['password'])
                login(request, user)

                return JsonResponse({'status': 200, 'message': 'Registration successful'})
        return JsonResponse({'status': 400, 'message': 'missed info'})
"""

from django.contrib.auth import authenticate, login
from django.shortcuts import redirect
from django.http import HttpResponseBadRequest, JsonResponse

class RegisterView(View):
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('chat:lobby')
        form = CustomUserCreationForm()  # Create an empty form instance
        return render(request, 'account_app/auth.html', {'form': form})

    def post(self, request):
        form = CustomUserCreationForm(request.POST, request.FILES)
        if form.is_valid():
            print("Form is valid")  # Log success message

            user = form.save()

            # Profile picture handling
            profile_picture = request.FILES.get('profile_picture')  # Use .get() for optional field
            if profile_picture:
                profile_picture_file_path = os.path.join('profile_pictures', f'{user.id}.{profile_picture.name.split(".")[-1]}')  # Adjust path as needed
                with open(profile_picture_file_path, 'wb+') as destination:
                    for chunk in profile_picture.chunks():
                        destination.write(chunk)
                user.profile_picture = profile_picture_file_path
                user.save()

            login(request, user)
            return JsonResponse({'status': 200, 'message': 'Registration successful'})
        else:
            # Handle form validation errors
            errors = form.errors.as_json()
            print(f"Form validation errors: {errors}")  # Log detailed validation errors
            return HttpResponseBadRequest(JsonResponse({'status': 400, 'message': errors}, safe=False))

@login_required
def user_logout(request):
    logout(request)
    return redirect('account:login')

"""
class CheckOtp(View):
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('chat:lobby')
        return redirect('account:login')

    def post(self, request):
        token = request.POST.get('token')
        code = request.POST.get('code')

        if token and code:
            try:
                new_user = Otp.objects.get(token=token, code=code)
                user = User.objects.create_user(
                    username=new_user.username,
                    first_name=new_user.first_name,
                    last_name=new_user.last_name,
                    email=new_user.email,
                    password=new_user.password
                )
                login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                new_user.delete()
                return JsonResponse({'status': 200, 'username': user.username})
            except:
                return JsonResponse({'status': 400, 'message': 'Invalid code'})
        else:
            return JsonResponse({'status': 400, 'message': 'missed info'})
"""
        
import random
from django.core.files.base import ContentFile

class CheckOtp(View):
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('chat:lobby')

        if request.GET.get('action') == 'otp':  # Check for OTP action
            # Generate a one-time PIN
            pin = str(random.randint(100000, 999999))
            request.session['otp_pin'] = pin  # Store PIN in session

            # Add PIN to the context for template access
            context = {'pin': pin}
            return render(request, 'account_app/auth.html', context)  # Replace with your template
        else:
            # Handle login or other actions based on request parameters
            return redirect('account:register')

    def post(self, request):
        submitted_pin = request.POST.get('pin')
        profile_picture = request.FILES.get('profile_picture')  # Access uploaded profile picture

        if submitted_pin and request.session.get('otp_pin'):
            if submitted_pin == request.session.pop('otp_pin'):  # Verify PIN and remove from session
                # Use details from request (adapt based on your form structure)
                username = request.POST.get('username')
                email = request.POST.get('email')
                first_name = request.POST.get('first_name')
                last_name = request.POST.get('last_name')
                password = request.POST.get('password')

                user = User.objects.create_user(
                    username=username,
                    email=email,
                    first_name=first_name,
                    last_name=last_name,
                    password=password
                )

                if profile_picture:
                    # Save profile picture to the user model (adapt based on your model field)
                    user.profile_picture.save(profile_picture.name, ContentFile(profile_picture.read()))

                login(request, user, backend='django.contrib.auth.backends.ModelBackend')
                return JsonResponse({'status': 200, 'username': user.username})
            else:
                return JsonResponse({'status': 400, 'message': 'Invalid PIN'})
        else:
            return JsonResponse({'status': 400, 'message': 'Missed information'})




class ForgotPasswordView(View):
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        email = request.GET.get('email', None)
        if email:
            try:
                user = User.objects.get(email=email)
            except:
                return JsonResponse({'status': 400, 'message': 'User not found'})
            random_code = randint(100000, 999999)
            email_sent = send_email(random_code, email)
            if email_sent:
                token = str(uuid4())
                Otp.objects.create(
                    username=user.username,
                    email=user.email,
                    code=random_code,
                    token=token,
                )
                return JsonResponse({'status': 200, 'token': token})
            else:
                return JsonResponse({
                    'status': 500,
                    'message': 'Service OTP encountered an error. Please try again. If the error is not resolved, contact support'
                })
        else:
            return JsonResponse({'status': 400, 'message': 'Data not sent'})

    def post(self, request):
        token = request.POST.get('token')
        code = request.POST.get('code')

        if token and code:
            try:
                user = Otp.objects.get(token=token, code=code)
                username = user.username
            except:
                return JsonResponse({'status': 400, 'message': 'Code is wrong'})
            find_user = User.objects.get(username=username)
            login(request, find_user)
            user.delete()
            return JsonResponse({'status': 200, 'username': username})
        else:
            return JsonResponse({'status': 400,  'message': 'Data not sent'})
        

@login_required
def user_info(request):
    user = request.user  # Access the currently logged-in user

    # You can customize the context dictionary according to your needs:
    context = {
        'username': user.username,
        'email': user.email,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'profile_picture': user.profile_picture.url if user.profile_picture else None,  # Handle cases where no profile picture exists
    }

    return render(request, 'account_app/user_info.html', context)  # Replace with your template name


from .forms import EditProfileForm  # Assuming your form is in a separate file named 'forms.py'

@login_required
def edit_profile(request):
    if request.method == 'POST':
        form = EditProfileForm(request.POST, request.FILES, instance=request.user)  # Include request.FILES for profile picture
        if form.is_valid():
            form.save()
            return redirect('account:user_info')
    else:
        form = EditProfileForm(instance=request.user)

    context = {'form': form}
    return render(request, 'account_app/edit_profile.html', context)
