$(document).ready(function() {
    $("#userInfoButton, #otherButtonId").click(function(e) {  // Target both buttons by ID
      e.preventDefault();  // Prevent default form submission
  
      var url = $(this).data("url");  // Get the URL from the clicked button's data-url attribute
  
      $.ajax({
        url: url,
        method: "GET",
        success: function(response) {
          $("#userInfoContent").html(response);  // Update the modal content with the fetched response
          $('.modal').modal('handleUpdate');  // Bootstrap v5+ syntax
        },
        error: function(error) {
          console.error("Error fetching content:", error);  // Log any errors
          // Display user-friendly error message in the modal (optional)
        }
      });
    });
});



const chatMessageInput = document.getElementById('chat-message-input');
const chatMessageSubmit = document.getElementById('chat-message-submit');
const fileInput = document.getElementById('fileInput');
const roomName = '{{ context.room_name }}';  // Replace with actual variable name

// Function for retrieving new messages using long polling
function receiveNewMessages() {
  // Fetch initial messages (if not already done)
  if (!initialMessagesFetched) {
      fetch(`/chat/${roomName}/messages/`, { method: 'GET' })  // New endpoint for initial messages
          .then(response => response.json())
          .then(data => {
              // Update chat interface with initial messages
              data.forEach(message => {
                  const messageElement = createMessageElement(message);
                  document.querySelector('#message-container').appendChild(messageElement);
              });
              initialMessagesFetched = true;  // Mark initial messages fetched
          })
          .catch(error => {
              console.error('Error fetching initial messages:', error);
          });
  }

// Function to create a message element for display (reusable)
function createMessageElement(message) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('msg_cotainer');
  messageElement.innerHTML = `
    <span class="username">${message.username}</span>
    <span class="content">${message.content}</span>
    <span class="msg_time_send">${message.created_at}</span>
  `;
  return messageElement;
}

// Handle message submission with JavaScript for a better experience
chatMessageSubmit.addEventListener('click', (event) => {
  event.preventDefault(); // Prevent default form submission

  const message = chatMessageInput.value.trim();  // Trim whitespace
  const formData = new FormData();
  formData.append('message', message);

  if (fileInput.files.length > 0) {
    const image = fileInput.files[0];
    formData.append('image', image);
  }

  const form = document.getElementById('chat-message-form'); // Get the form element
  const messageSendingUrl = form.action; // Extract URL from form's action attribute

  // Send AJAX request with FormData
  fetch(messageSendingUrl, {
    method: 'POST',
    body: formData,
    processData: false,
    contentType: false,
  })
  .then(response => {
      // Check for successful response
      if (response.ok) {
          return response.json();  // Parse JSON data
      } else {
          console.error('Error sending message:', response.statusText);
          // Handle errors
      }
  })
  .then(data => {
      // Process received JSON data (update chat interface without page reload)
      console.log('Message sent successfully:', data);
      // ... (update chat interface using the received data) ...
  })
  .catch(error => {
      console.error('Error sending message:', error);
      // Handle network or other errors
  });

  // Fallback: Submit form if JavaScript is disabled (not recommended)
  document.getElementById('chat-message-form').addEventListener('submit', (event) => {
    if (!window.fetch) {  // Check if fetch API is not available
      event.preventDefault(); // Submit the form manually
    }
  });

  // Start long polling initially to retrieve existing messages
  receiveNewMessages();
}); // Removed the extra semicolon here
